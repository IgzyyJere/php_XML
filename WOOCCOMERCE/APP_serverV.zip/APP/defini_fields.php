<?php

class QueryMain_Context{
$user = "webzyco1_mojecip";
$db = "webzyco1_mojecipele";
$passW = "~$FA6i_)mToA";
}

?>