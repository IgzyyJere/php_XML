        <li>
            <a href="/vivo2/0/pod_top/prikaz/o/">izdvojene nekretnine</a>
	    </li>