<?php

$spajanjeServer = "localhost";
$spajanjeUser = "nekrettomisl_adm";
$spajanjePass = "yukADr3t2avu";
$spajanjeBaza = "nekrettomisl_nekrettomisl";

?>
