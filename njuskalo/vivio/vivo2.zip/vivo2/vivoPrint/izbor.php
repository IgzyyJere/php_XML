kartica &raquo; <input type="radio" id="template" name="template" value="1"><br />
potvrda &raquo; <input type="radio" id="template" name="template" value="2"><br />
ponuda &raquo; <input type="radio" id="template" name="template" value="3"><br />  
