<hr class="ruler">

<div class="agencijskiFooter">
        
Tel : +385 (1) 3638095    Fax : +385 (1) 36 68 714 Mob : +385 (91) 2505 819 +385 (91) 3638 095<br />  
E-mail : papirus-agencija@zg.t-com.hr     web : www.papirus-nekretnine.hr<br />
matični broj obrta: 92033849<br />
Žiro račun kod ZABA Zagreb: 2360000-1101643763<br />
Žiro račun kod Privredne banke Zagreb d.d 2340009-1160228240<br /> 
        
</div>