-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2019 at 09:48 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testnekrenine`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `CustomerLevel` () RETURNS VARCHAR(10) CHARSET latin1 BEGIN
    DECLARE lvl varchar(10);
 
update nekretnine.wp_posts set post_type =  'property'
where post_type like  'product';
set lvl = 'uspjeh';

 
 RETURN (lvl);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `TransferPost_Properties` (`p` VARCHAR(10), `vt` VARCHAR(10)) RETURNS VARCHAR(10) CHARSET latin1 BEGIN
    DECLARE lvl varchar(10);
 
update nekretnine.wp_posts set post_type =  p
where post_type like  vt;


set lvl = 'uspjeh';

 
 RETURN (lvl);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `author_name` varchar(500) NOT NULL,
  `price` varchar(500) NOT NULL,
  `ISBN` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author_name`, `price`, `ISBN`, `category`) VALUES
(1, 'C++ By Example', 'John', '500', 'PR-123-A1', 'Programming'),
(2, 'Java Book', 'Jane davis', '450', 'PR-456-A2', 'Programming'),
(3, 'Database Management Systems', 'Mark', '300', 'DB-123-ASD', 'Database'),
(4, 'Harry Potter and the Order of the Phoenix', 'J.K. Rowling', '650', 'FC-123-456', 'Novel'),
(5, 'Pride and Prejudice', 'Jane Austen', '450', 'FC-456-678', 'Novel'),
(6, 'Learning Web Development ', 'Michael', '300', 'ABC-123-456', 'Web Development'),
(7, 'Professional PHP & MYSQL', 'Programmer Blog', '340', 'PR-123-456', 'Web Development');

-- --------------------------------------------------------

--
-- Table structure for table `grupe`
--

CREATE TABLE `grupe` (
  `id` int(16) NOT NULL,
  `vrsta` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grupa` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `skupina` int(4) DEFAULT NULL,
  `naziv` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `grupe`
--

INSERT INTO `grupe` (`id`, `vrsta`, `grupa`, `skupina`, `naziv`) VALUES
(1, 'stanovi prodaja', 'jednosobni', 1, 'jednosobni stan'),
(2, 'stanovi najam', 'jednosobni', 2, 'jednosobni stan'),
(3, 'kuće prodaja', 'obiteljske kuće', 3, 'obiteljska kuća'),
(4, 'kuće najam', 'obiteljske kuće', 4, 'obiteljska kuća'),
(5, 'poslovni prodaja', 'uredi', 5, 'ured'),
(6, 'poslovni najam', 'uredi', 6, 'ured'),
(7, 'zemljišta prodaja', 'građevinska', 7, 'građevinsko zemljište'),
(8, 'zemljišta najam', 'građevinska', 8, 'građevinsko'),
(9, 'ostalo prodaja', 'garaže', 9, 'garaža'),
(10, 'ostalo najam', 'garaže', 10, 'garaža'),
(11, 'stanovi prodaja', 'dvosobni', 11, 'dvosobni stan'),
(12, 'stanovi prodaja', 'trosobni', 12, 'trosobni stan'),
(13, 'stanovi prodaja', 'četverosobni i veći', 13, 'četverosobni li veći stan'),
(14, 'stanovi prodaja', 'apartmani', 14, 'apartman'),
(15, 'stanovi najam', 'dvosobni', 15, 'dvosobni stan'),
(16, 'stanovi najam', 'trosobni', 16, 'trosobni stan'),
(17, 'stanovi najam', 'četverosobni i veći', 17, 'četverosobnni ili veći stan'),
(18, 'poslovni prodaja', 'skladišta', 18, 'skladište'),
(19, 'poslovni najam', 'skladišta', 19, 'skladište'),
(20, 'poslovni prodaja', 'poslovno stambeni', 20, 'poslovno stambeni prostor'),
(21, 'poslovni najam', 'poslovno stambeni', 21, 'poslovno stambeni prostor'),
(22, 'stanovi prodaja', 'garsonjere', 22, 'garsonjera'),
(23, 'stanovi najam', 'garsonjere', 23, 'garsonjera'),
(24, 'kuće prodaja', 'vikendice', 3, 'vikendica'),
(25, 'turistički prodaja', 'apartmanske', 25, 'apartmanska kuća'),
(26, 'kuće prodaja', 'vile', 3, 'vila'),
(27, 'kuće najam', 'vikendice', 4, 'vikendica'),
(28, 'turistički najam', 'apartmanske', 28, 'apartmanska kuća'),
(29, 'kuće najam', 'vile', 4, 'vila'),
(30, 'zemljišta prodaja', 'poljoprivredna', 30, 'poljoprivredno zemljište'),
(31, 'zemljišta prodaja', 'turistička', 7, 'turističko zemljište'),
(32, 'zemljišta prodaja', 'industraijska', 7, 'industrijsko zemljište'),
(33, 'zemljišta najam', 'poljoprivredna', 33, 'poljoprivredno zemljište'),
(34, 'zemljišta najam', 'turistička', 8, 'turističko zemljište'),
(35, 'zemljišta najam', 'industrijska', 8, 'industrijsko zemljište'),
(36, 'turistički prodaja', 'hoteli', 25, 'hotel'),
(37, 'turistički prodaja', 'kampovi', 25, 'kamp'),
(38, 'turistički prodaja', 'turistička naselja', 25, 'turističko naselje'),
(39, 'turistički najam', 'hoteli', 28, 'hotel'),
(40, 'turistički najam', 'kampovi', 28, 'kamp'),
(41, 'turistički najam', 'turistička naselja', 28, 'turističko naselje'),
(42, 'poslovni prodaja', 'ulični lokali', 5, 'ulični lokal'),
(43, 'poslovni prodaja', 'ugostiteljski objekti', 5, 'ugostiteljski objekt'),
(44, 'poslovni najam', 'ulični lokali', 6, 'ulični lokal'),
(45, 'poslovni najam', 'ugostiteljski objekti', 6, 'ugostiteljski objekt'),
(46, 'stanovi najam', 'apartmani', 46, 'apartman'),
(47, 'turistički prodaja', 'ostalo', 25, 'turistički objekt'),
(48, 'turistički najam', 'ostalo', 28, 'turistički objekt'),
(49, 'ostalo prodaja', 'otoci', 9, 'otok'),
(50, 'ostalo prodaja', 'dvorci', 9, 'dvorac'),
(51, 'ostalo najam', 'otoci', 10, 'otok'),
(52, 'ostalo najam', 'dvorci', 10, 'dvorac'),
(53, 'ostalo prodaja', 'gradilišta', 9, 'gradilište'),
(54, 'ostalo najam', 'gradilišta', 10, 'gradilište'),
(55, 'poslovni prodaja', 'hale', 5, 'hala'),
(56, 'poslovni najam', 'hale', 6, 'hala'),
(57, 'stanovi prodaja', 'penthouse', 13, 'penthouse'),
(58, 'stanovi najam', 'penthouse', 17, 'penthouse'),
(59, 'zemljišta prodaja', 'zelena zona', 7, 'zelena zona'),
(60, 'zemljišta najam', 'zelena zona', 8, 'zelena zona'),
(61, 'ostalo prodaja', 'projekti', 9, 'projekti'),
(62, 'ostalo najam', 'projekti', 10, 'projekti'),
(63, 'turistički prodaja', 'moteli', 25, 'moteli'),
(64, 'turistički najam', 'moteli', 28, 'moteli'),
(65, 'turistički prodaja', 'marine', NULL, 'marine'),
(66, 'turistički najam', 'marine', NULL, 'marine');

-- --------------------------------------------------------

--
-- Table structure for table `sliketransfer`
--

CREATE TABLE `sliketransfer` (
  `ID_nekrenina` bigint(20) NOT NULL,
  `slk1` text NOT NULL,
  `slk2` text NOT NULL,
  `slk3` text NOT NULL,
  `slk4` text NOT NULL,
  `slk5` text NOT NULL,
  `slk6` text,
  `slk7` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sliketransfer`
--

INSERT INTO `sliketransfer` (`ID_nekrenina`, `slk1`, `slk2`, `slk3`, `slk4`, `slk5`, `slk6`, `slk7`) VALUES
(2, 'http://nekretnine-tomislav.hr/slike/1031611.jpg', 'http://nekretnine-tomislav.hr/slike/1031612.jpg', 'http://nekretnine-tomislav.hr/slike/1031613.jpg', 'http://nekretnine-tomislav.hr/slike/1031614.jpg', 'http://nekretnine-tomislav.hr/slike/1031615.jpg', 'http://nekretnine-tomislav.hr/slike/1031616.jpg', 'http://nekretnine-tomislav.hr/slike/1031617.jpg'),
(4, 'http://nekretnine-tomislav.hr/slike/1043177.jpg', 'http://nekretnine-tomislav.hr/slike/1043178.jpg', 'http://nekretnine-tomislav.hr/slike/1043179.jpg', 'http://nekretnine-tomislav.hr/slike/1043180.jpg', 'http://nekretnine-tomislav.hr/slike/1043181.jpg', 'http://nekretnine-tomislav.hr/slike/', 'http://nekretnine-tomislav.hr/slike/'),
(7, 'http://nekretnine-tomislav.hr/slike/1046272.jpg', 'http://nekretnine-tomislav.hr/slike/1046273.jpg', 'http://nekretnine-tomislav.hr/slike/1046274.jpg', 'http://nekretnine-tomislav.hr/slike/1046275.jpg', 'http://nekretnine-tomislav.hr/slike/1046276.jpg', 'http://nekretnine-tomislav.hr/slike/1046277.jpg', 'http://nekretnine-tomislav.hr/slike/1046278.jpg'),
(8, 'http://nekretnine-tomislav.hr/slike/1046279.jpg', 'http://nekretnine-tomislav.hr/slike/1046280.jpg', 'http://nekretnine-tomislav.hr/slike/1046281.jpg', 'http://nekretnine-tomislav.hr/slike/1046282.jpg', 'http://nekretnine-tomislav.hr/slike/1046283.jpg', 'http://nekretnine-tomislav.hr/slike/1046284.jpg', 'http://nekretnine-tomislav.hr/slike/1046285.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `vivoostalo`
--

CREATE TABLE `vivoostalo` (
  `id` int(12) NOT NULL,
  `grupa` int(8) DEFAULT NULL,
  `regija` int(4) DEFAULT NULL,
  `zupanija` int(2) DEFAULT NULL,
  `mikrolokacija` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `povrsina` float(10,2) DEFAULT NULL,
  `cijena` int(8) DEFAULT NULL,
  `mjesto` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adresa` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `imeIPrezime` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobitel` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `povTelefon` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maxCijena` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `minCijena` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pregledali` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `napomena` text COLLATE utf8_unicode_ci,
  `slike` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vrstaPonude` int(2) DEFAULT NULL,
  `brojPosjeta` int(16) NOT NULL DEFAULT '0',
  `datumUnosa` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datumIzmjene` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aktivno` int(2) DEFAULT NULL,
  `obrisano` int(2) DEFAULT NULL,
  `lat` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `lon` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `zoomLvl` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `tlocrt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provizije` int(2) DEFAULT NULL,
  `agent` int(2) DEFAULT NULL,
  `otplataRata` int(2) DEFAULT NULL,
  `otplataVisina` int(8) DEFAULT NULL,
  `pdv` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `arhiva` int(1) DEFAULT NULL,
  `grad` int(4) DEFAULT NULL,
  `kvart` int(4) DEFAULT NULL,
  `prebivaliste` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adaptacija` int(4) DEFAULT NULL,
  `brojPogleda` int(8) DEFAULT NULL,
  `katCes` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zkUlozak` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `katOpcina` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `morePogled` int(2) DEFAULT NULL,
  `moreUdaljenost` int(6) DEFAULT NULL,
  `idProjekta` int(8) DEFAULT NULL,
  `idObjekta` mediumint(8) DEFAULT NULL,
  `statusProdaje` int(1) DEFAULT NULL,
  `tlocrtPDF` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poredak` int(16) DEFAULT NULL,
  `njuskalo_id` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idInterni` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datoteke` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `naslovoglasa` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vivoostalo`
--

INSERT INTO `vivoostalo` (`id`, `grupa`, `regija`, `zupanija`, `mikrolokacija`, `povrsina`, `cijena`, `mjesto`, `adresa`, `imeIPrezime`, `mobitel`, `povTelefon`, `maxCijena`, `minCijena`, `pregledali`, `email`, `napomena`, `slike`, `vrstaPonude`, `brojPosjeta`, `datumUnosa`, `datumIzmjene`, `aktivno`, `obrisano`, `lat`, `lon`, `zoomLvl`, `tlocrt`, `provizije`, `agent`, `otplataRata`, `otplataVisina`, `pdv`, `arhiva`, `grad`, `kvart`, `prebivaliste`, `adaptacija`, `brojPogleda`, `katCes`, `zkUlozak`, `katOpcina`, `morePogled`, `moreUdaljenost`, `idProjekta`, `idObjekta`, `statusProdaje`, `tlocrtPDF`, `poredak`, `njuskalo_id`, `idInterni`, `datoteke`, `naslovoglasa`) VALUES
(2, 9, 1, 22, 'Otokara Keršovanija', 16.00, 13000, 'Zagreb', 'Otokara Keršovanija 15', 'Jasminka Modrić', '091/5135-416', '0', '0', '0', '0', '0', '0', '31611,31612,31613,31614,31615,31616,31617', NULL, 0, 'Mon, 25 Nov 2013 16:35:24 +0100', NULL, NULL, NULL, '', '', '', NULL, NULL, 4, 0, 0, '0', NULL, 9, 76, 'Zagreb', 0, 1, '0', '0', '0', 0, 0, NULL, NULL, NULL, NULL, 2, NULL, '0', NULL, '0'),
(3, 9, 1, 22, 'Zagrebačka cesta', 17.64, 12000, 'Zagreb', 'zagrebačka cesta 76B', 'Zdravko Horvat', '098 208 879', '0', '0', '0', '0', '0', '0', NULL, NULL, 0, 'Wed, 12 Mar 2014 16:07:00 +0100', NULL, 1, NULL, '', '', '', NULL, NULL, 4, 0, 0, '0', NULL, 138, 144, 'Mihaljekov Jarek 34c', 0, 1, '6943/1', '6640 pod 133', 'Vrapče Novo', NULL, 0, NULL, NULL, NULL, NULL, 3, NULL, '0', NULL, '0'),
(4, 9, 1, 22, 'Šubićeva ', 16.85, 10000, 'Zagreb', 'Šubićeva 65', 'Goran Opačak', '095/5632822', '0', '0', '0', '0', '0', '0', '43177,43178,43179,43180,43181', NULL, 0, 'Thu, 27 Aug 2015 21:05:18 +0200', 'Thu, 27 Aug 2015 21:19:44 +0200', 1, NULL, '', '', '', NULL, NULL, 4, 0, 0, '0', NULL, 8, 64, 'Ravenska 13', 0, 1, '0', '0', '0', 0, 0, NULL, NULL, NULL, NULL, 4, NULL, '0', NULL, '0'),
(7, 10, 1, 22, 'Gundulićeva', 30.00, 200, 'Zagreb', 'Gundulićeva 21a', 'Rajko Dejdar', '098/9320665', '0', '0', '0', 'na trajno korištenje, vanknjižno vlasništvo', 'karavanic.marina@gmail.com', '0', '46272,46273,46274,46275,46276,46277,46278', NULL, 0, 'Fri, 21 Oct 2016 13:15:43 +0200', NULL, 1, NULL, '', '', '', NULL, NULL, 4, 0, 0, '0', NULL, 8, 57, '0', 2016, 1, '0', '0', '0', 0, 0, NULL, NULL, NULL, NULL, 7, NULL, '0', NULL, '0'),
(8, 9, 1, 22, 'Gundulićeva', 25.00, 15000, 'Zagreb', 'Gundulićeva 21a', 'Rajko Dejdar', '098/9320665', '0', '0', '0', 'na trajno korištenje, vanknjižno vlasništvo', 'karavanic.marina@gmail.com', '0', '46279,46280,46281,46282,46283,46284,46285', NULL, 0, 'Fri, 21 Oct 2016 13:34:44 +0200', 'Fri, 21 Oct 2016 13:43:05 +0200', 1, NULL, '', '', '', NULL, NULL, 4, 0, 0, '0', NULL, 8, 57, '0', 2016, 1, '0', '0', '0', 0, 0, NULL, NULL, NULL, NULL, 8, NULL, '0', NULL, '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grupe`
--
ALTER TABLE `grupe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vivoostalo`
--
ALTER TABLE `vivoostalo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `grupe`
--
ALTER TABLE `grupe`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `vivoostalo`
--
ALTER TABLE `vivoostalo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
